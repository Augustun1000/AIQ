#!/bin/bash
#Pcmanfm daemon
pcmanfm -d &
#Xterm config
xrdb -merge .Xresources &
#wallpaper
feh --bg-fill /home/augustun1000/Downloads/wallpaper.png &
#Wifi
#nm-applet
